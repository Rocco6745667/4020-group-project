const express = require("express");
const axios = require("axios");
const mongoose = require("mongoose");
const Question = require("../models/Question");

const router = express.Router();

// Fetch all questions from MongoDB
router.get("/questions", async (req, res) => {
  try {
    const questions = await Question.find({ chatGPTResponse: "" }); // Fetch unanswered questions
    res.json(questions);
  } catch (error) {
    res.status(500).json({ error: "Error fetching questions: " + error.message });
  }
});

// Process a question through ChatGPT and save the response
router.post("/process/:id", async (req, res) => {
  const { id } = req.params;

  try {
    // Fetch question by ID
    const question = await Question.findById(id);
    if (!question) {
      return res.status(404).json({ error: "Question not found" });
    }

    // Send the question to ChatGPT
    const chatGPTResponse = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4", // Use the appropriate ChatGPT model
        messages: [{ role: "user", content: question.question }],
        max_tokens: 200, // Adjust token limit as needed
      },
      {
        headers: {
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    const responseText = chatGPTResponse.data.choices[0].message.content;

    // Update MongoDB document with ChatGPT's response
    question.chatGPTResponse = responseText;
    await question.save();

    res.json({
      question: question.question,
      response: responseText,
    });
  } catch (error) {
    res.status(500).json({ error: "Error processing question: " + error.message });
  }
});

module.exports = router;
