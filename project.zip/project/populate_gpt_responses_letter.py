from dotenv import load_dotenv
import os
import openai
import time
from pymongo import MongoClient

# Load environment variables
load_dotenv()

# OpenAI API Key
openai.api_key = os.getenv("OPENAI_API_KEY")
if not openai.api_key:
    raise ValueError("OpenAI API key not found. Check your .env file.")

# MongoDB Connection
MONGO_URI = os.getenv("MONGO_URI")
if not MONGO_URI:
    raise ValueError("MongoDB URI not found. Check your .env file.")

client = MongoClient(MONGO_URI)
db = client["ChatGPT_Evaluation"]

# Collections to process
collections = ["Computer_Security", "History", "Social_Science"]

def fetch_gpt_response_as_letter(question, options):
    options_text = "\n".join([f"{key}: {value}" for key, value in options.items()])
    prompt = f"""
    Here is a multiple-choice question:
    {question}

    Options:
    {options_text}

    Please respond with only the letter of the correct option (A, B, C, or D).
    """
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=10,
            temperature=0
        )
        return response["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"Error fetching GPT response: {e}")
        return None

# Process collections
for collection_name in collections:
    collection = db[collection_name]
    print(f"Processing collection: {collection_name}")

    # Debug: Check if the collection contains documents
    total_docs = collection.count_documents({})
    print(f"Total documents in {collection_name}: {total_docs}")

    # Fetch documents to process
    documents = collection.find({
        "$or": [
            {"chatGPTResponse": ""},
            {"chatGPTResponse": None},
            {"chatGPTResponse": {"$exists": False}}
        ]
    })

    # Debug: Check if the query fetches any documents
    matching_docs = list(documents)
    print(f"Documents matching query in {collection_name}: {len(matching_docs)}")

    for doc in matching_docs:
        print(f"Processing document: {doc}")
        # Your existing processing logic here


    for doc in documents:
        question = doc["question"]
        options = doc["options"]

        print(f"Processing document ID {doc['_id']} with question: {question}")

        # Fetch GPT response
        gpt_response = fetch_gpt_response_as_letter(question, options)
        print(f"GPT Response: {gpt_response}")

        if gpt_response in ["A", "B", "C", "D"]:
            # Update the document with the GPT response
            collection.update_one(
                {"_id": doc["_id"]},
                {"$set": {"chatGPTResponse": gpt_response}}
            )
            print(f"Document {doc['_id']} updated with response: {gpt_response}")
        else:
            print(f"Invalid GPT response for document {doc['_id']}.")

        # Avoid hitting API rate limits
        time.sleep(1)
