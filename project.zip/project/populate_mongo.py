from pymongo import MongoClient
import pandas as pd

# MongoDB connection string
MONGO_URI = "mongodb+srv://abmbz13:estarossa@cluster0.duuc1.mongodb.net/ChatGPT_Evaluation?retryWrites=true&w=majority"

# Connect to MongoDB
client = MongoClient(MONGO_URI)
db = client["ChatGPT_Evaluation"]

# File paths for the three CSVs
csv_files = {
    "Computer_Security": r"C:\Users\Abel\OneDrive\Desktop\Docs\project\computer_security_test.csv",
    "History": r"C:\Users\Abel\OneDrive\Desktop\Docs\project\prehistory_test.csv",
    "Social_Science": r"C:\Users\Abel\OneDrive\Desktop\Docs\project\sociology_test.csv"
}

# Process each CSV file and populate MongoDB
for collection_name, file_path in csv_files.items():
    print(f"Processing file: {file_path}")

    # Load CSV into pandas DataFrame
    try:
        df = pd.read_csv(file_path)
        print(f"Columns in {collection_name} CSV:", df.columns.tolist())
    except Exception as e:
        print(f"Failed to read CSV file {file_path}: {e}")
        continue

    # Transform rows into MongoDB documents
    documents = []
    for _, row in df.iterrows():
        try:
            question = row["Question"]
            options = {
                "A": row["A"],
                "B": row["B"],
                "C": row["C"],
                "D": row["D"]
            }
            correct_answer = row["Anticipated Answer"]
            gpt_response = row.get("GPT Response", "")  # Use existing GPT Response if present, else default to ""

            document = {
                "question": question,
                "options": options,
                "correctAnswer": correct_answer,
                "chatGPTResponse": gpt_response
            }
            documents.append(document)
        except KeyError as e:
            print(f"Missing column in row for {collection_name}: {e}")
            continue

    # Insert documents into MongoDB
    try:
        collection = db[collection_name]
        result = collection.insert_many(documents)
        print(f"Inserted {len(result.inserted_ids)} documents into the '{collection_name}' collection.")
    except Exception as e:
        print(f"An error occurred while inserting into '{collection_name}': {e}")
