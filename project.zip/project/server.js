const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const csvParser = require("csv-parser");
const fs = require("fs");
require("dotenv").config();

const app = express();

// Middleware for parsing JSON
app.use(express.json());


// MongoDB Connection
const mongoURI = process.env.MONGO_URI;
console.log("MongoDB URI:", mongoURI);
mongoose
  .connect(mongoURI)
  .then(() => console.log("Connected to MongoDB Atlas"))
  .catch((err) => console.error("Failed to connect to MongoDB:", err));

// Define Mongoose schema for CSV data
const CsvDataSchema = new mongoose.Schema({
  question: String,
  options: [String],
  correctAnswer: String,
  chatGPTResponse: { type: String, default: "" },
});

const CsvData = mongoose.model("CsvData", CsvDataSchema);

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// API to upload and process a CSV file
app.post("/api/upload-csv", (req, res) => {
  const filePath = path.join(__dirname, "uploads", "data.csv"); // Replace with actual file upload handling

  const records = [];

  fs.createReadStream(filePath)
    .pipe(csvParser())
    .on("data", (row) => {
      // Assuming CSV columns: question, option1, option2, ..., correctAnswer
      const options = Object.values(row).slice(1, -1); // Extract all columns except the first and last
      const record = {
        question: row.question,
        options: options,
        correctAnswer: row.correctAnswer,
        chatGPTResponse: "",
      };
      records.push(record);
    })
    .on("end", async () => {
      try {
        // Insert records into MongoDB
        await CsvData.insertMany(records);
        res.status(201).json({ message: "CSV data uploaded and processed successfully" });
      } catch (error) {
        res.status(500).json({ error: "Failed to save data to MongoDB" });
      }
    })
    .on("error", (error) => {
      console.error("Error reading CSV:", error);
      res.status(500).json({ error: "Error reading CSV file" });
    });
});

// Fetch processed data
app.get("/api/examples", async (req, res) => {
  try {
    const examples = await CsvData.find();
    res.status(200).json(examples);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch data" });
  }
});

// Error-handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Something went wrong!" });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
